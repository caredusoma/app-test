# Calorie Tracker Mobile (Flutter)

## Run
1. Install Flutter SDK: https://docs.flutter.dev/get-started/install
2. `flutter pub get`
3. Run on emulator or device: `flutter run`

The app expects the backend to be accessible at http://10.0.2.2:5000 when running on Android emulator,
or http://localhost:5000 when running on web or desktop. Adjust accordingly.
