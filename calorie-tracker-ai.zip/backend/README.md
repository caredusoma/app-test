# Calorie Tracker Backend (Node.js)

## Setup
1. Copy `.env.example` to `.env` and add your USDA_API_KEY.
2. `npm install`
3. `npm run dev`

API:
POST /api/food/lookup
Body: { "text": "3 tacos al pastor" }
