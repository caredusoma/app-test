import fetch from "node-fetch";

export async function searchUSDA(query) {
  const apiKey = process.env.USDA_API_KEY;
  const url = `https://api.nal.usda.gov/fdc/v1/foods/search?query=${encodeURIComponent(query)}&pageSize=1&api_key=${apiKey}`;

  const res = await fetch(url);
  const data = await res.json();

  if (!data.foods || data.foods.length === 0) return null;

  const food = data.foods[0];
  const kcal = (food.foodNutrients || []).find(n => (n.nutrientName || "").toLowerCase().includes("energy") && (n.unitName || "").toUpperCase().includes("KCAL"));

  return {
    name: food.description,
    kcalPerServing: kcal ? kcal.value : null
  };
}
