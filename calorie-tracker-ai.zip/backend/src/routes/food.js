import express from "express";
import { searchUSDA } from "../utils/usda.js";

const router = express.Router();

router.post("/lookup", async (req, res) => {
  try {
    const { text } = req.body;
    if (!text) return res.status(400).json({ error: "Texto de comida requerido" });

    const result = await searchUSDA(text);
    if (!result) return res.status(404).json({ error: "No encontrado en base USDA" });

    res.json({
      food: result.name,
      kcalPerServing: result.kcalPerServing
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Error en búsqueda" });
  }
});

export default router;
