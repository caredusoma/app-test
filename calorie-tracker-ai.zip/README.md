# Calorie Tracker AI - Starter Repo

Este repositorio contiene un backend Node.js y una app Flutter mínima junto con un workflow de GitHub Actions
para compilar un APK automáticamente al hacer push a `main`.

**Importante**: Este entorno no puede compilar el APK por ti. En su lugar incluimos un workflow de CI que lo hará en GitHub Actions,
o puedes compilar localmente en tu máquina (instrucciones abajo).

## Opciones para obtener el APK
1. **Usar GitHub Actions** (recomendado):
   - Sube este repositorio a GitHub.
   - Ve a Actions → ejecuta el workflow o haz push a `main`.
   - Descarga el artifact `app-release-apk` desde la ejecución.

2. **Compilar localmente**:
   - Instala Flutter SDK y Android SDK.
   - Ve a `mobile/`, ejecuta `flutter pub get`.
   - Conecta un emulador o usa `flutter build apk --release`.
