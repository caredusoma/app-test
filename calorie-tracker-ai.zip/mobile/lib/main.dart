import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

void main() {
  runApp(const CalorieTrackerApp());
}

class CalorieTrackerApp extends StatelessWidget {
  const CalorieTrackerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Calorie Tracker AI',
      home: CalorieHomePage(),
    );
  }
}

class CalorieHomePage extends StatefulWidget {
  @override
  State<CalorieHomePage> createState() => _CalorieHomePageState();
}

class _CalorieHomePageState extends State<CalorieHomePage> {
  final _controller = TextEditingController();
  String _result = "";

  Future<void> searchFood(String food) async {
    // For Android emulator use 10.0.2.2, for other platforms adjust host
    final url = Uri.parse("http://10.0.2.2:5000/api/food/lookup");
    try {
      final res = await http.post(url, headers: {
        "Content-Type": "application/json"
      }, body: jsonEncode({"text": food}));

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        setState(() {
          _result = "${data['food']} - ${data['kcalPerServing']} kcal";
        });
      } else {
        setState(() {
          _result = "No encontrado o error: \${res.statusCode}";
        });
      }
    } catch (e) {
      setState(() {
        _result = "Error comunicando con backend: \$e";
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Calorie Tracker AI")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _controller,
              decoration: const InputDecoration(labelText: "¿Qué comiste?"),
            ),
            ElevatedButton(
              onPressed: () => searchFood(_controller.text),
              child: const Text("Buscar calorías"),
            ),
            const SizedBox(height: 20),
            Text(_result, style: const TextStyle(fontSize: 18)),
          ],
        ),
      ),
    );
  }
}
